/*
 * Copyright 2002-2019 Intel Corporation.
 * 
 * This software is provided to you as Sample Source Code as defined in the accompanying
 * End User License Agreement for the Intel(R) Software Development Products ("Agreement")
 * section 1.L.
 * 
 * This software and the related documents are provided as is, with no express or implied
 * warranties, other than those that are expressly stated in the License.
 */

__declspec(dllexport) void nothing() {}

#if defined(TARGET_IA32)

__declspec(dllexport) __declspec(naked) void* baserel_in_probe()
{
    __asm {
        xor eax, eax
        // Emit base relocation. Located at offset 3 from entry point.
        mov eax, baserel_in_probe
        ret
    };
}

#endif
