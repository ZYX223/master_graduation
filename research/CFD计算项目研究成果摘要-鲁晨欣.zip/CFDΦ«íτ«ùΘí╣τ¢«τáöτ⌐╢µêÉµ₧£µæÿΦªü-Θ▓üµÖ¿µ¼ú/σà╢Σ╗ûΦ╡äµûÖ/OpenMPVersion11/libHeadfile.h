//headfiles addition

#include "omp.h"
#include<iostream>
#include<cmath>
#include<fstream>
#include<string.h>
#include<sstream>
#include <iomanip>
#include<algorithm>
#include <unistd.h>
#include <malloc.h>
#include <memory>  
#include <ctime>  


//macro definition

#define pi 3.141592654
#define forAll(begin,up,i) \
        for(int i=begin;i<up;i++)


//namespace definition

using namespace std;



